#include "pch.h"
#include "PuzzleState.h"


PuzzleState::PuzzleState()
{
}


PuzzleState::~PuzzleState()
{
}
