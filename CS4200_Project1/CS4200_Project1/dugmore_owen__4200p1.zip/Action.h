#pragma once
class Action
{
public:
	virtual void Dummy() = 0;
};