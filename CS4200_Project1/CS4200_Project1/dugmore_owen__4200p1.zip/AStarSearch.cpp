#include "AStarSearch.h"
#include <iostream>
#include <queue>

using namespace std;

void removeElement(vector<Node>* vector, Node element)
{
	for (int i = 0; i < vector->size(); i++)
	{
		if ((*vector)[i].GetState() == element.GetState())
		{
			vector->erase(vector->begin() + i);
		}
	}
}

AStarSearch::Solution* AStarSearch::Search(Problem* problem, Heuristic* heuristic)
{
	shared_ptr<Node> node(new Node(problem->InitialState(), nullptr, nullptr, 0, 0));
	priority_queue<Node, vector<Node>, CompareNodes> frontier;
	vector<Node> frontierList; // for searching the frontier
	Solution* solution = new Solution();
	vector<Action*> actions = problem->GetActions();
	vector<Node> exploredSet;
	frontier.push(*node);
	frontierList.push_back(*node);
	while (!frontier.empty())
	{
		//Node nodePtr = frontier.top();
		node = shared_ptr<Node>(new Node(frontier.top()));
		frontier.pop();
		removeElement(&frontierList, *node);
		cout << "Distance from goal: " << node->GetEstimatedCost() << endl;
		if (problem->GoalTest(node->GetState()))
		{
			solution->finalNode = *node;
			break;
		}

		exploredSet.push_back(*node);

		for (int i = 0; i < actions.size(); i++)
		{
			Node* child = ChildNode(problem, heuristic, node, actions[i]);
			if (child == nullptr) continue;
			solution->nodeCount++;
			cout << "Nodes generated: " << solution->nodeCount << endl;
			State* childState = child->GetState();
			bool found = false;
			bool foundFrontier = false;
			int frontierPos;
			for (int i = 0; i < frontierList.size(); i++)
			{
				if (*childState == *frontierList[i].GetState())
				{
					found = true;
					foundFrontier = true;
					frontierPos = i;
					break;
				}
			}
			if (!found)
			{
				for (int i = 0; i < exploredSet.size(); i++)
				{
					if (*childState == *exploredSet[i].GetState())
					{
						found = true;
						break;
					}
				}
			}

			if (!found)
			{
				frontier.push(*child);
				frontierList.push_back(*child);
			}
			else if (foundFrontier && frontierList[frontierPos].GetEstimatedCost() > child->GetEstimatedCost())
			{
				cout << "Replace child in frontier..." << endl;
				frontier = priority_queue<Node, vector<Node>, CompareNodes>(); // clear priority queue
				// so we can replace this node
				for (int i = 0; i < frontierPos; i++)
				{
					frontier.push(frontierList[i]);
				}
				frontier.push(*child);
				for (int i = frontierPos + 1; i < frontierList.size(); i++)
				{
					frontier.push(frontierList[i]);
				}

			}

		}
	}

	return solution;
}

Node* AStarSearch::ChildNode(Problem* problem, Heuristic* heuristic, shared_ptr<Node> parent, Action* action)
{
	//Node* parent = new Node(parent);
	State* state; 
	try
	{
		state = problem->Result(parent->GetState(), action);
	}
	catch (const std::exception&)
	{
		return nullptr;
	}
	
	int estCost = parent->GetPathCost() + heuristic->Estimate(state);
	Node* child = new Node(state, parent, action, parent->GetPathCost() + 1, estCost);
	return child;
}